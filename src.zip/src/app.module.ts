import { Module } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { UserModule } from './user/user.module';
import { PermissionsService } from './permissions/permissions.service';
import { DocumentsModule } from './documents/documents.module';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    AuthModule, 
    UserModule,
    DocumentsModule,
    TypeOrmModule.forRoot({
      type: 'postgres',
      host:"localhost",
      port:5432,
      username:"demo_user", 
      password:"admin",
      database:"doc_rag",
      autoLoadEntities: true,
      synchronize: true,     
    }),  
  ], 
  //providers: [PermissionsService],
})
export class AppModule {}