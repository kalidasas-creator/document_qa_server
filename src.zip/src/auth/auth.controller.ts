import { Controller, Post, Body, BadRequestException, Get, UseGuards, Req } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthService } from './auth.service';
import { SignupDto } from './dto/signup.dto';
import { LoginDto } from './dto/login.dto';
import { JwtAuthGuard } from './jwt.guard';
import { Roles } from './roles.decorator';
import { RolesGuard } from './roles.guard';
import { PermissionsService } from '../permissions/permissions.service';

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService, private permService: PermissionsService) {}

  @Post('onboard')
  async onboardUser(@Body() dto: SignupDto) {
    const exists = await this.authService.findByUsername(dto.username);
    if (exists) throw new BadRequestException('Username already exists');
    const user = await this.authService.signup(dto);
    return { id: user.id, username: user.username, role: user.role };
  }

  @Post('login')
  async login(@Body() dto: LoginDto) {
    return this.authService.login(dto);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin')
  @Get('permission-matrix')
  permissionMatrix() {
    return this.permService.getPermissionMatrix();
  }

  @UseGuards(JwtAuthGuard)
  @Get('me')
  me(@Req() req:any) {
    return req.user;
  }
}