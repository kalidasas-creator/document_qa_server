import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { UserModule } from '../user/user.module';
import { JwtModule } from '@nestjs/jwt';
import { JwtStrategy } from './/strategies/jwt.strategy';
import { RolesGuard } from './roles.guard';
// Ensure the correct path to PermissionsService
import { PermissionsService } from '../permissions/permissions.service';

@Module({
  imports: [UserModule, JwtModule.register({ secret: process.env.JWT_SECRET || 'secret' })],
  controllers: [AuthController],
  providers: [AuthService, JwtStrategy, RolesGuard,PermissionsService],
  exports: [AuthService],
})
export class AuthModule {}