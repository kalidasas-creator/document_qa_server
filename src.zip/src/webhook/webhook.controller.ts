import { Controller, Post, Body, HttpCode, InternalServerErrorException, Logger } from '@nestjs/common';
import { ApiTags, ApiBody, ApiOperation } from '@nestjs/swagger';
import { WebhookService } from './webhook.service';

@ApiTags('webhook')
@Controller('webhook')
export class WebhookController {
  private readonly logger = new Logger(WebhookController.name);
  constructor(private readonly webhookService: WebhookService) {}

  @Post('callback')
  @HttpCode(200)
  @ApiOperation({ summary: 'Handle ingestion status callbacks from Python worker' })
  @ApiBody({ schema: { example: { documentId: '...', percent: 50, statusMessage: 'Processing...' }}})
  async handleCallback(@Body() body: any) {
    try {
      await this.webhookService.processWebhook(body);
      return { status: 'received' };
    } catch (err) {
      this.logger.error(`Error processing webhook callback: ${err?.message || err}`);
      throw new InternalServerErrorException('Failed to process webhook callback');
    }
  }
}